#include "ClassMenu.h"
//#include "Test.h"
#include <cstring>
#include <iostream>
using namespace std;

int main() {
    CarCompany company;
    Menu menu(company);
    menu.selectMainMenu();

    return 0;
}

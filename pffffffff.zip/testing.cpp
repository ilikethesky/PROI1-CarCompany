#include "Test.cpp"

 int main() {
CarCompanyTests x;
x.Test1();
x.Test2();
x.Test3();

return 0;
 }

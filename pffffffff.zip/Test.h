#ifndef CARTESTS_
#define CARTESTS_

#include "ClassMenu.h"

class CarCompanyTests {
public:
    void Test1();
    void Test2();
    void Test3();
    void Test4();
};

#endif // CARTESTS_
